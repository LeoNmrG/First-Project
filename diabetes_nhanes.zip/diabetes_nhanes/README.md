https://www.cdc.gov/nchs/nhis/nhis_2016_data_release.htm

Downloaded Sample Adult file (CSV data)

survey summary
ftp://ftp.cdc.gov/pub/Health_Statistics/NCHS/Dataset_Documentation/NHIS/2016/srvydesc.pdf